"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ModeToggle } from "@/components/mode-toggle"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const pathname = usePathname()

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  const navItems = [
    { label: "首页", href: "/" },
    { label: "场地介绍", href: "/facility" },
    { label: "预订", href: "/booking" },
    { label: "活动日历", href: "/events" },
    { label: "图库", href: "/gallery" },
    { label: "常见问题", href: "/faq" },
    { label: "联系我们", href: "/contact" },
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center space-x-2">
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Lencana_Sekolah_Jenis_Kebangsaan_%28C%29_Kung_Ming.jpg-8J99lQj8UOASkfgV0TJBxVwOePZpDE.jpeg"
              alt="斗湖公民学校"
              className="h-10 w-auto"
            />
            <span className="font-bold text-xl">斗湖公民学校</span>
          </Link>
        </div>

        <nav className="hidden md:flex items-center gap-6">
          {navItems.map((item, index) => (
            <Link
              key={index}
              href={item.href}
              className={`text-sm font-medium transition-colors hover:text-primary ${
                pathname === item.href ? "text-primary" : "text-muted-foreground"
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <ModeToggle />
          <Link href="/booking" className="hidden md:block">
            <Button>立即预约</Button>
          </Link>
          <Button variant="ghost" size="icon" className="md:hidden" onClick={toggleMenu}>
            <Menu className="h-6 w-6" />
            <span className="sr-only">Toggle menu</span>
          </Button>
        </div>
      </div>

      {/* 移动端菜单 */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 bg-background md:hidden">
          <div className="container flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <img
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Lencana_Sekolah_Jenis_Kebangsaan_%28C%29_Kung_Ming.jpg-8J99lQj8UOASkfgV0TJBxVwOePZpDE.jpeg"
                alt="斗湖公民学校"
                className="h-10 w-auto"
              />
              <span className="font-bold text-xl">斗湖公民学校</span>
            </Link>
            <Button variant="ghost" size="icon" onClick={toggleMenu}>
              <X className="h-6 w-6" />
              <span className="sr-only">Close menu</span>
            </Button>
          </div>
          <nav className="container grid gap-6 py-6">
            {navItems.map((item, index) => (
              <Link
                key={index}
                href={item.href}
                className={`text-lg font-medium ${pathname === item.href ? "text-primary" : "text-muted-foreground"}`}
                onClick={toggleMenu}
              >
                {item.label}
              </Link>
            ))}
            <Link href="/booking" onClick={toggleMenu}>
              <Button className="w-full">立即预约</Button>
            </Link>
          </nav>
        </div>
      )}
    </header>
  )
}

