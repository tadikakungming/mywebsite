import Link from "next/link"
import { Calendar, Clock, MapPin, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import HeroSection from "@/components/hero-section"
import FeaturedEvents from "@/components/featured-events"
import BookingSteps from "@/components/booking-steps"
import Testimonials from "@/components/testimonials"
import FacilityFeatures from "@/components/facility-features"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <HeroSection />

      {/* 大礼堂信息 */}
      <section className="py-12 px-4 md:px-6 lg:px-8 bg-white">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-8">斗湖公民学校大礼堂</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <p className="text-lg mb-6">
                我们的大礼堂是斗湖地区最现代化的多功能场所，配备先进的音响、灯光和投影系统，
                可举办各类活动，包括演讲、音乐会、戏剧表演、婚礼和社区聚会等。
              </p>
              <div className="grid grid-cols-2 gap-4">
                <Card>
                  <CardContent className="p-4 flex items-center space-x-2">
                    <Users className="h-5 w-5 text-primary" />
                    <span>容纳500人</span>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 flex items-center space-x-2">
                    <MapPin className="h-5 w-5 text-primary" />
                    <span>中心位置</span>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 flex items-center space-x-2">
                    <Clock className="h-5 w-5 text-primary" />
                    <span>全天可用</span>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 flex items-center space-x-2">
                    <Calendar className="h-5 w-5 text-primary" />
                    <span>提前预约</span>
                  </CardContent>
                </Card>
              </div>
              <div className="mt-8">
                <Link href="/booking">
                  <Button size="lg" className="w-full md:w-auto">
                    立即预约
                  </Button>
                </Link>
              </div>
            </div>
            <div className="rounded-lg overflow-hidden shadow-lg">
              <img
                src="/placeholder.svg?height=400&width=600"
                alt="斗湖公民学校大礼堂"
                className="w-full h-auto object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <FacilityFeatures />
      <BookingSteps />
      <FeaturedEvents />
      <Testimonials />

      {/* 联系我们 */}
      <section className="py-12 px-4 md:px-6 lg:px-8 bg-muted">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">有任何疑问？</h2>
          <p className="text-lg mb-8">请联系我们的管理员获取更多信息</p>
          <Link href="/contact">
            <Button variant="outline" size="lg">
              联系我们
            </Button>
          </Link>
        </div>
      </section>
    </div>
  )
}

